$( document ).ready(function() {

    $('.slider').slick({
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: false,
      arrows:true,

      
    });
  
  });



  $ (document) .ready(function(){


    $('.pro_sec_slider').slick({
      dots: true,
      infinite: true,
      arrows:false,

      slidesToShow: 2,
      slidesToScroll: 2,
      
    

  });
  
});



// owl

$(document).ready(function(){
  $(".owl-carousel").owlCarousel(

    {


      nav:true,
      dots:false,
      loop:true,
    }
  );
});















